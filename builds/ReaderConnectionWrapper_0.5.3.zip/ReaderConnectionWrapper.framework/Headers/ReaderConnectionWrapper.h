//
//  ReaderConnectionWrapper.h
//  ReaderConnectionWrapper
//
//  Created by Jakub Mejtský on 30/10/2018.
//  Copyright © 2018 AHEAD iTec, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ReaderConnectionWrapper.
FOUNDATION_EXPORT double ReaderConnectionWrapperVersionNumber;

//! Project version string for ReaderConnectionWrapper.
FOUNDATION_EXPORT const unsigned char ReaderConnectionWrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ReaderConnectionWrapper/PublicHeader.h>


